
import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.mongodb.client.MongoCollection
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.nio.file.Files
import java.nio.file.Paths

/**
 * Created by Ajay on 28/9/16.
 */
class MakeWorldLeaders {
    static String LEADER_FOLDER_LOCATION = "leaders"
    static Map<String, String> MONGO_PARAMS = [:]

    public static void main(String[] args) {
        println("started app MakeWorldLeaders")
        MongoCollection collection = getMongoCollection(args)
        println("Inserting test data to ensure Mongo Connectivity.")
        collection.insertOne(new org.bson.Document([name:"test"]))
        collection.deleteOne(new org.bson.Document([name:"test"]))
        println("Mongo Connectivity ensured!")
        if(scrapWorldLeaders(collection)){
            println("Scraping World Leaders terminated with success")
        }else {
            println("Scraping World Leaders terminated with fauilure")
        }
    }
    static MongoCollection getMongoCollection(String[] args){
        MONGO_PARAMS.put("HOST_URL", "localhost")
        MONGO_PARAMS.put("PORT", "27017")
        MONGO_PARAMS.put("USER_NAME", "")
        MONGO_PARAMS.put("PASSWORD", "")
        MONGO_PARAMS.put("DATABASE", "infoplease")
        MONGO_PARAMS.put("COLLECTION", "world_leaders")
        if(args?.length){
            String[] params = args[0].split(",")
            for(String param:params){
                String[] paramPair = param.split(":")
                MONGO_PARAMS.put(paramPair[0],paramPair[1])
            }
        } else {
            println("Warning: Parameters not provided for Mongo Connection! Continuing with defaults.")
        }
        MongoCredential credential = MongoCredential.createMongoCRCredential(MONGO_PARAMS.USER_NAME, MONGO_PARAMS.DATABASE, MONGO_PARAMS.PASSWORD.toCharArray())
        List<MongoCredential> credentialList = MONGO_PARAMS.USER_NAME?.length() ? [credential]: []
        MongoClient client = new MongoClient(new ServerAddress(MONGO_PARAMS.HOST_URL,
                Integer.parseInt(MONGO_PARAMS.PORT)), credentialList)
        MongoCollection collection = client.getDatabase(MONGO_PARAMS.DATABASE).getCollection(MONGO_PARAMS.COLLECTION)
        return collection
    }

    static boolean scrapWorldLeaders(MongoCollection collection){
        String makeFilePath = LEADER_FOLDER_LOCATION+"/Makefile"
        println("scraping World Leaders with makeFilePath : ${makeFilePath} and collectionName : ${MONGO_PARAMS.COLLECTION}")

        File makefile = new File(makeFilePath)
        if(!makefile.isDirectory() && makefile.exists()){
            Files.walk(Paths.get(LEADER_FOLDER_LOCATION)).filter({ location ->
                !(location.toFile().name == "Makefile")
            }).each {location ->
                location.toFile().delete()
            }
            println("Now building process for executing Makefile")
            ProcessBuilder builder = new ProcessBuilder(
                    "/bin/bash", "-c", "cd \"${LEADER_FOLDER_LOCATION}\" && make all")
            builder.redirectErrorStream(true)
            println("Initiated build process. Please wait ...")
            Process process = builder.start()
            BufferedReader r = new BufferedReader(new InputStreamReader(process.getInputStream()))
            String line
            while (true) {
                line = r.readLine()
                if (line == null) {
                    break
                }
            }
            println("Build complete.")
            println("Now scraping documents to MongoDB")

            Files.walk(Paths.get(LEADER_FOLDER_LOCATION)).filter({location ->
                File file = location.toFile()
                file.name.contains(".htm")
            }).each {location ->
                File file = location.toFile()
                scrapDocument(file, collection)
            }
            return true
        } else {
            System.err.println("Makefile doesn't exist inside leaders directory!")
            return false
        }

    }
    static void scrapDocument(File file, MongoCollection collection){
        Document doc = Jsoup.parse(file, null)
        Map worldLeader = [:]
        worldLeader.url_path = file.path
        worldLeader.category = "WORLD_LEADERS"
        worldLeader.sub_category = "WORLD_LEADERS"
        Element elem = doc?.getElementById("countryOutput")?.getElementById("countryName")
        worldLeader.updateddate = elem?.getElementById("lastUpdateDate")?.text()
        worldLeader.country = elem?.getElementsByClass("countryName")?.text()
        elem = doc?.getElementById("countryOutput")?.getElementById("cosDataDisplay")?.nextElementSibling()
        if(elem?.tagName() != "ul"){
            elem = doc?.getElementById("countryOutput")?.getElementsByTag("ul")?.first()
        }
        if(elem){
            List<Map> leaders = []
            elem.getElementsByTag("li").each {Element li ->
                Map leader = [:]
                leader.position = li?.getElementsByClass("title")?.first()?.children()?.first()?.text()
                leader.name = li?.getElementsByClass("cos_name")?.first()?.children()?.first()?.text()
                leaders.add(leader)
            }
            worldLeader.leaders = leaders
        }
        collection.insertOne(new org.bson.Document(worldLeader))
    }
}
